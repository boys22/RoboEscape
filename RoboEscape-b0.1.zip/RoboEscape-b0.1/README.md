# RoboEscape (b0.1)

RoboEscape는 고장 난 공장을 탈출하는 로봇 로그라이크예요. 브라우저만 있으면 PC와 휴대폰에서 바로 플레이할 수 있어요. 파일은 `index.html` 하나뿐이에요.

## 조작

| 동작 | PC | 모바일 (가로 화면) |
|---|---|---|
| 이동 | WASD / 방향키 | 왼쪽 화면을 엄지로 끌기 |
| 공격 (3연타) | J (또는 좌클릭) | 공격 버튼 |
| 점프 → 내려찍기 | K → 공중에서 J | 점프 → 공중에서 공격 |
| 렌치 투척 | L (또는 우클릭) | 투척 버튼 |
| 대시 | Space | 대시 버튼 |
| 일시정지 | Esc | 화면 위 일시정지 버튼 |

조준은 자동이에요. 이동 방향에 가까운 적을 노려요.

## GitHub Pages로 올리기 (휴대폰에서 보기)

명령어 없이 GitHub 웹사이트에서만 할 수 있어요.

1. GitHub에 로그인하고 오른쪽 위 **+ → New repository**를 눌러요.
2. 저장소 이름을 정해요. 예: `RoboEscape`
3. **Public**을 선택하고 **Create repository**를 눌러요. 무료 계정은 Public이어야 Pages를 쓸 수 있어요.
4. 저장소 화면에서 **uploading an existing file** 링크(또는 **Add file → Upload files**)를 눌러요.
5. 이 폴더의 `index.html`, `README.md`, `CHANGELOG.md`를 끌어다 놓고, 메시지에 `b0.1`이라고 적은 뒤 **Commit changes**를 눌러요.
6. 저장소 **Settings → Pages**로 가서 아래처럼 설정하고 **Save**를 눌러요.
   - Source: **Deploy from a branch**
   - Branch: **main**, 폴더: **/ (root)**
7. 1~2분 뒤 Pages 화면 위쪽에 주소가 나타나요. 형식은 아래와 같아요.

   ```
   https://<GitHub 아이디>.github.io/RoboEscape/
   ```

8. 휴대폰에서 이 주소를 열고 **가로로** 들면 플레이할 수 있어요.

### 홈 화면에 추가하면 더 편해요

- **아이폰 (Safari):** 공유 버튼 → **홈 화면에 추가**
- **안드로이드 (Chrome):** 메뉴(⋮) → **홈 화면에 추가**

홈 화면 아이콘으로 열면 주소창 없이 화면을 더 넓게 써요.

### 버전 태그 남기기 (선택)

저장소 오른쪽의 **Releases → Create a new release**에서 태그 이름을 `b0.1`로 만들어 두면, 나중에 이 버전으로 되돌아가기 쉬워요.

## 참고

- 글꼴은 Google Fonts에서 불러와요. 인터넷이 안 되는 환경에서는 기본 글꼴로 보여요.
- 고른 로봇은 그 브라우저에만 기억돼요.
- 순위표는 아직 없어요. 같은 날에는 누구나 같은 맵과 보상 후보로 플레이해요(데일리 시드).
